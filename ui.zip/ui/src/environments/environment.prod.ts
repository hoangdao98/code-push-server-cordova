// environments/environment.prod.ts
export const environment = {
  production: true,
  apiUrl: 'https://your-prod-api.com/api',
};
