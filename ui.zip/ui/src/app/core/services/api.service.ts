// core/services/api.service.ts
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BaseApiService } from './base-api.service';
import { App } from '../models/app.model';
import { Deployment, DeploymentPackage, DeploymentMetrics } from '../models/deployment.model';

@Injectable({
  providedIn: 'root'
})
export class ApiService extends BaseApiService {
  getApps(options?: RequestOptions): Observable<App[]> {
    return this.get<App[]>('/apps', options);
  }

  getAppDetails(appName: string, options?: RequestOptions): Observable<App> {
    return this.get<App>(`/apps/${appName}`, options);
  }

  getDeployments(appName: string, options?: RequestOptions): Observable<any[]> {
    return this.get<any[]>(`/apps/${appName}/deployments`, options);
  }

  createApp(app: Partial<App>, options?: RequestOptions): Observable<App> {
    return this.post<App>('/apps', app, options);
  }

  updateApp(appName: string, app: Partial<App>, options?: RequestOptions): Observable<App> {
    return this.put<App>(`/apps/${appName}`, app, options);
  }

  deleteApp(appName: string, options?: RequestOptions): Observable<void> {
    return this.delete<void>(`/apps/${appName}`, options);
  }

  getDeployment(appName: string, deploymentName: string, options?: RequestOptions): Observable<Deployment> {
    return this.get<Deployment>(`/apps/${appName}/deployments/${deploymentName}`, options);
  }

  createDeployment(appName: string, deployment: Partial<Deployment>, options?: RequestOptions): Observable<Deployment> {
    return this.post<Deployment>(`/apps/${appName}/deployments`, deployment, options);
  }

  updateDeployment(appName: string, deploymentName: string, deployment: Partial<Deployment>, options?: RequestOptions): Observable<Deployment> {
    return this.put<Deployment>(`/apps/${appName}/deployments/${deploymentName}`, deployment, options);
  }

  deleteDeployment(appName: string, deploymentName: string, options?: RequestOptions): Observable<void> {
    return this.delete<void>(`/apps/${appName}/deployments/${deploymentName}`, options);
  }

  getDeploymentMetrics(appName: string, deploymentName: string, options?: RequestOptions): Observable<DeploymentMetrics> {
    return this.get<DeploymentMetrics>(`/apps/${appName}/deployments/${deploymentName}/metrics`, options);
  }
}