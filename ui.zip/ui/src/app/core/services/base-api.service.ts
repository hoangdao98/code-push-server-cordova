// core/services/base-api.service.ts
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface RequestOptions {
  baseUrl?: string;
  headers?: Record<string, string>;
}

@Injectable()
export abstract class BaseApiService {
  protected defaultBaseUrl = environment.apiUrl;

  constructor(protected http: HttpClient) {}

  protected getHeaders(customHeaders?: Record<string, string>): HttpHeaders {
    const defaultHeaders = {
      'Content-Type': 'application/json',
      ...this.getAuthHeaders()
    };
    return new HttpHeaders({ ...defaultHeaders, ...customHeaders });
  }

  protected getAuthHeaders(): Record<string, string> {
    const token = localStorage.getItem('token');
    return token ? { 'Authorization': `Bearer ${token}` } : {};
  }

  protected get<T>(path: string, options?: RequestOptions): Observable<T> {
    const baseUrl = options?.baseUrl || this.defaultBaseUrl;
    return this.http.get<T>(`${baseUrl}${path}`, {
      headers: this.getHeaders(options?.headers)
    });
  }

  protected post<T>(path: string, body: any, options?: RequestOptions): Observable<T> {
    const baseUrl = options?.baseUrl || this.defaultBaseUrl;
    return this.http.post<T>(`${baseUrl}${path}`, body, {
      headers: this.getHeaders(options?.headers)
    });
  }

  protected put<T>(path: string, body: any, options?: RequestOptions): Observable<T> {
    const baseUrl = options?.baseUrl || this.defaultBaseUrl;
    return this.http.put<T>(`${baseUrl}${path}`, body, {
      headers: this.getHeaders(options?.headers)
    });
  }

  protected delete<T>(path: string, options?: RequestOptions): Observable<T> {
    const baseUrl = options?.baseUrl || this.defaultBaseUrl;
    return this.http.delete<T>(`${baseUrl}${path}`, {
      headers: this.getHeaders(options?.headers)
    });
  }
}