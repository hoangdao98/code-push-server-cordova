export interface DeploymentMetrics {
    active: number;
    downloaded: number;
    installed: number;
    failed: number;
  }
  
  export interface DeploymentPackage {
    description: string;
    appVersion: string;
    isMandatory: boolean;
    label: string;
    packageHash: string;
    metrics?: DeploymentMetrics;
  }
  
  export interface Deployment {
    name: string;
    key: string;
    package?: DeploymentPackage;
    createdTime: Date;
    status: 'active' | 'inactive';
  }