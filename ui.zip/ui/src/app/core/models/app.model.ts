// core/models/app.model.ts
export interface App {
  name: string;
  platform: 'ios' | 'android';
  createdTime: Date;
}
