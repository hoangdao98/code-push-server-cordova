// features/apps/apps-list/apps-list.component.ts
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzModalModule, NzModalService } from 'ng-zorro-antd/modal';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { App } from '@core/models/app.model';

@Component({
  selector: 'app-apps-list',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    NzTableModule,
    NzButtonModule,
    NzModalModule,
    NzFormModule,
    NzSelectModule,
  ],
  template: `
    <div class="p-6">
      <div class="flex justify-between mb-4">
        <h2 class="text-2xl font-semibold">Applications</h2>
        <button nz-button nzType="primary" (click)="createApp()">
          Create New App
        </button>
      </div>

      <nz-table #basicTable [nzData]="apps">
        <thead>
          <tr>
            <th>Name</th>
            <th>Platform</th>
            <th>Created</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let app of basicTable.data">
            <td>
              <a [routerLink]="['/apps', app.name]">{{ app.name }}</a>
            </td>
            <td>{{ app.platform }}</td>
            <td>{{ app.createdTime | date }}</td>
            <td>
              <button nz-button nzType="link" (click)="editApp(app)">
                Edit
              </button>
              <button nz-button nzType="link" nzDanger (click)="deleteApp(app)">
                Delete
              </button>
            </td>
          </tr>
        </tbody>
      </nz-table>
    </div>

    <!-- Create/Edit Modal Template -->
    <ng-template #modalContent>
      <form [formGroup]="appForm" (ngSubmit)="submitForm()">
        <nz-form-item>
          <nz-form-label>Name</nz-form-label>
          <nz-form-control>
            <input nz-input formControlName="name" placeholder="App name" />
          </nz-form-control>
        </nz-form-item>
        <nz-form-item>
          <nz-form-label>Platform</nz-form-label>
          <nz-form-control>
            <nz-select formControlName="platform">
              <nz-option nzValue="ios" nzLabel="iOS"></nz-option>
              <nz-option nzValue="android" nzLabel="Android"></nz-option>
            </nz-select>
          </nz-form-control>
        </nz-form-item>
      </form>
    </ng-template>
  `,
})
export class AppsListComponent {
  private modal = inject(NzModalService);
  private fb = inject(FormBuilder);
  private apiService = inject(ApiService);
  apps: App[] = [];
  appForm = this.fb.group({
    name: ['', Validators.required],
    platform: ['', Validators.required],
  });

  ngOnInit() {
    this.loadApps();
  }

  loadApps() {
    this.apiService.getApps().subscribe(apps => {
      this.apps = apps;
    });
  }

  createApp() {
    this.appForm.reset();
    this.modal.create({
      title: 'Create New App',
      content: this.modalContent,
      onOk: () => this.submitForm()
    });
  }

  editApp(app: App) {
    this.appForm.patchValue(app);
    this.modal.create({
      title: 'Edit App',
      content: this.modalContent,
      onOk: () => this.submitForm(app)
    });
  }

  deleteApp(app: App) {
    this.modal.confirm({
      nzTitle: 'Are you sure?',
      nzContent: `Do you want to delete ${app.name}?`,
      nzOkType: 'danger',
      nzOnOk: () => {
        this.apiService.deleteApp(app.name).subscribe(() => {
          this.loadApps();
        });
      }
    });
  }

  submitForm(existingApp?: App) {
    if (this.appForm.valid) {
      const formValue = this.appForm.value;
      if (existingApp) {
        this.apiService.updateApp(existingApp.name, formValue).subscribe(() => {
          this.loadApps();
        });
      } else {
        this.apiService.createApp(formValue).subscribe(() => {
          this.loadApps();
        });
      }
    }
  }
}
