import { Routes } from '@angular/router';

// export const routes: Routes = [
//   {
//     path: 'apps',
//     component: AppListComponent
//   },
  // {
  //   path: 'apps/:id',
  //   loadComponent: () => import('./features/apps/app-detail/app-detail.component')
  //     .then(m => m.AppDetailComponent)
  // },
  // {
  //   path: 'collaborators',
  //   loadComponent: () => import('./features/collaborators/collaborator-list/collaborator-list.component')
  //     .then(m => m.CollaboratorListComponent)
  // },
  // {
  //   path: '',
  //   redirectTo: 'apps',
  //   pathMatch: 'full'
  // }
// ];